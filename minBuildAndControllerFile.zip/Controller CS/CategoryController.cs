﻿using Ecommerce.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace Ecommerce.Controllers
{
    public class CategoryController : ApiController
    {
        ECommeraceEntity db = new ECommeraceEntity();
        public string base64Str = null;

        [HttpPost]
        public ResultModel AddCategory()
        {
            var exMessage = string.Empty;
            try
            {
                string uploadPath = "~/UploadedFiles";
                HttpPostedFile file = null;
                if(HttpContext.Current.Request.Files.Count > 0)
                {
                    file = HttpContext.Current.Request.Files.Get("CategoryImage");
                }
                if(null == file)
                {
                    return new ResultModel { Message = "Image file not found", Status = 0, Response = null };
                    
                }
                if (!(file.ContentLength > 0))
                {
                    return new ResultModel { Message = "Image file not found", Status = 0, Response = null };
                }
                string CategoryName = HttpContext.Current.Request.Params.Get("CategoryName");
                string Category_Type = HttpContext.Current.Request.Params.Get("Category_Type");

                if (!Directory.Exists(HttpContext.Current.Server.MapPath(uploadPath)))
                {
                    Directory.CreateDirectory(HttpContext.Current.Server.MapPath(uploadPath));
                }
                file.SaveAs(HttpContext.Current.Server.MapPath($"{uploadPath}/{file.FileName}"));

                var uriReq = HttpContext.Current.Request;

                var baseUri = uriReq.Url.Scheme + "://" + uriReq.Url.Authority;

                Category _ObjCat = new Category();
                _ObjCat.CategoryName = CategoryName;
                _ObjCat.CategoryImage = file.FileName;
                _ObjCat.Category_Type = Category_Type;

                var result = db.Categories.Where(a => a.CategoryName == CategoryName).ToList();

                if (result.Count == 0)
                {
                    db.Categories.Add(_ObjCat);
                    db.SaveChanges();
                    return new ResultModel { Message = "Data saved", Status = 1, Response = _ObjCat };
                }
                else
                {
                    return new ResultModel { Message = "Category already exist", Status = 0, Response = null };
                }


                    
                
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.Message, Status = 0, Response = null };
            }
        }


        //[HttpPost]
        //public async Task<ResultModel> AddCategory(Category model)
        //{
        //    try
        //    {

        //        var file = HttpContext.Current.Request.Files.Count > 0 ? HttpContext.Current.Request.Files[0] : null;

        //        if (file != null && file.ContentLength > 0)
        //        {
        //            Category _ObjCat = new Category();

        //            _ObjCat.CategoryName = model.CategoryName;
        //            _ObjCat.CategoryImage = HttpContext.Current.Request.Files[0].FileName;
        //            _ObjCat.Category_Type = model.Category_Type;

        //            var result = db.Categories.Where(a => a.CategoryName == model.CategoryName).ToList();

        //            if (result.Count == 0)
        //            {
        //                SaveImage();
        //                db.Categories.Add(_ObjCat);
        //                await db.SaveChangesAsync();

        //                if (_ObjCat != null)
        //                {
        //                    return new ResultModel { Message = "Success", Status = 1, Response = _ObjCat };
        //                }
        //                else
        //                {
        //                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = null };
        //                }
        //            }
        //            else
        //            {
        //                return new ResultModel { Message = "Category already exist", Status = 0, Response = null };
        //            }
        //        }
        //        else
        //        {
        //            return new ResultModel { Message = "Data Not Found", Status = 0, Response = null };
        //        }


        //    }
        //    catch (Exception ex)
        //    {
        //        return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
        //    }

        //}


        

     
        [HttpGet]
        public async Task<ResultModel> GetCategoryList()
        {
            try
            {
                var result = db.Categories.ToList();

                if (result != null)
                {
                    return new ResultModel { Message = "Success", Status = 0, Response = result };
                }
                else
                {
                    return new ResultModel { Message = "No data found", Status = 0, Response = null };
                }

            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }

        }

        [HttpPost]
        public async Task<ResultModel> GetCategoryByType(Category model)
        {
            ResultModel resultModel = new ResultModel();
            try
            {
                var registrations = db.Categories.Where(a => a.Category_Type == model.Category_Type).ToList();

                if (registrations != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = registrations };
                }
                else
                {
                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = null };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }

        }

    }
}
