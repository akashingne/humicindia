﻿using Ecommerce.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace Ecommerce.Controllers
{
    public class OrderController : ApiController
    {
        ECommeraceEntity db = new ECommeraceEntity();

        [HttpPost]
        public async Task<ResultModel> InsertOrder(Order model)
        {
            
            try
            {
              
                Order _objorder = new Order();
                _objorder.CustomerName = model.CustomerName;
                _objorder.UserName = model.UserName;
                _objorder.DeviceId = model.DeviceId;
                _objorder.Address = model.Address;
                _objorder.NoofProduct = model.NoofProduct;
                _objorder.PhoneNo = model.PhoneNo;
                _objorder.PaymentMode = model.PaymentMode;               
                _objorder.TotalAmount = model.TotalAmount;
                _objorder.OrderDate = model.OrderDate;
                _objorder.OrderTime = model.OrderTime;
                _objorder.TransactionId = model.TransactionId;
                _objorder.Order_Status = model.Order_Status;              
                _objorder.GstAmount = model.GstAmount;
                _objorder.DeliveryCharges = model.DeliveryCharges;
                _objorder.Delivery_Date = model.Delivery_Date;
                _objorder.Delivery_Time = model.Delivery_Time;
                _objorder.Received_Amount = model.Received_Amount;
                _objorder.Balance_Amount = model.Balance_Amount;
                _objorder.Delivery_Schedule = model.Delivery_Schedule;
                _objorder.Staff_Id = model.Staff_Id;
                _objorder.Staff_Name = model.Staff_Name;
                _objorder.Remainder_date = model.Remainder_date;

                db.Orders.Add(_objorder);
                db.SaveChanges();

                var CartDetail = db.Carts.Where(a => a.DeviceId == model.DeviceId && a.UserName == model.UserName).ToList();

                var Master = db.Orders.Where(a => a.DeviceId == model.DeviceId && a.UserName == model.UserName).ToList().Last();

                OrderHistory _objorderdet = new OrderHistory();

                foreach (var item in CartDetail)
                {
                    _objorderdet.DeviceId = item.DeviceId;
                    _objorderdet.UserName = model.UserName;
                    _objorderdet.OrderId = Master.Id;
                    _objorderdet.ProductName = item.ProductName;
                    _objorderdet.Product_Image = item.ProductImage;
                    _objorderdet.CategoryName = item.CategoryName;
                    _objorderdet.SubCategoryName = item.SubCategoryName;
                    _objorderdet.Quantity = item.Quantity;
                    _objorderdet.ProductCost = item.Amount;
                    _objorderdet.OfferPrice = item.OfferAmount;
                    _objorderdet.TotalAmount = item.TotalAmount;
                    _objorderdet.TotalCount = item.ItemCount;
                    _objorderdet.DeliveryCharges = model.DeliveryCharges;
                    _objorderdet.GSTAmount = model.GstAmount;                                        
                    _objorderdet.OrderDate = model.OrderDate;
                    _objorderdet.OrderTime = model.OrderTime;
                    _objorderdet.DeliveryDate = model.Delivery_Date;
                    _objorderdet.DeliveryTime = model.Delivery_Time;
                    _objorderdet.Order_Status = model.Order_Status;
                    _objorderdet.Delivery_Schedule = model.Delivery_Schedule;
                    _objorderdet.Transaction_Id = model.TransactionId;

                    db.OrderHistories.Add(_objorderdet);
                    db.SaveChanges();

                }

                
                foreach (var item in CartDetail)
                {
                    var _objcart = db.Carts.Where(a => a.Id == item.Id).ToList().Last();
                    
                    db.Entry(_objcart).State = EntityState.Deleted;
                    db.SaveChanges();

                }

                if (_objorder != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = 1 };
                }
                else
                {
                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = 0 };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }

        }


        [HttpPost]
        public async Task<ResultModel> GetIdViseData(Order model)
        {
            try
            {
                var result = db.Orders.Where(a => a.Id == model.Id).ToList();

                if (result != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = result };
                }
                else
                {
                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = 0 };
                }

            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        [HttpPost]
        public async Task<ResultModel> GetUsernameViseData(Order model)
        {
            try
            {
                var result = db.Orders.Where(a => a.UserName == model.UserName).ToList();

                if (result != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = result };
                }
                else
                {
                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = 0 };
                }

            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        [HttpGet]
        public async Task<ResultModel> GetAllOrder()
        {
            try
            {
                var result = db.Orders.ToList().OrderByDescending(a=> a.Delivery_Date);

                if (result != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = result };
                }
                else
                {
                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = 0 };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        [HttpPost]
        public async Task<ResultModel> AssignOrder(Order model)
        {
            try
            {
                var result = db.Orders.Where(a => a.Id == model.Id).FirstOrDefault();

                result.Staff_Id = model.Staff_Id;
                result.Staff_Name = model.Staff_Name;
                result.Order_Status = model.Order_Status;
                result.Delivery_Time = model.Delivery_Time;
                result.Delivery_Date = model.Delivery_Date;

                db.Entry(result).State = EntityState.Modified;
                db.SaveChanges();

                if(result != null)
                {
                    var OrderDetail = db.OrderHistories.Where(a => a.OrderId == model.Id).ToList();
                    foreach (var item in OrderDetail)
                    {
                        var _objorder = db.OrderHistories.Where(a => a.OrderId == item.OrderId).ToList().FirstOrDefault();

                        _objorder.Staff_Id = model.Staff_Id;
                        _objorder.Staff_Name = model.Staff_Name;
                        _objorder.Order_Status = model.Order_Status;
                        _objorder.DeliveryTime = model.Delivery_Time;
                        _objorder.DeliveryDate = model.Delivery_Date;


                        db.Entry(_objorder).State = EntityState.Modified;
                        db.SaveChanges();

                    }
                    return new ResultModel { Message = "Success", Status = 1, Response = 1 };
                }
                else
                {
                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = 0 };
                }

            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        [HttpPost]
        public async Task<ResultModel> UpdateOrderStatus (Order model)
        {
            try
            {
                var result = db.Orders.Where(a => a.Id == model.Id).FirstOrDefault();

                result.Order_Status = model.Order_Status;
                
                db.Entry(result).State = EntityState.Modified;
                db.SaveChanges();

                if (result != null)
                {
                    var OrderDetail = db.OrderHistories.Where(a => a.OrderId == model.Id).ToList();
                    foreach (var item in OrderDetail)
                    {
                        var _objorder = db.OrderHistories.Where(a => a.OrderId == item.OrderId).ToList().FirstOrDefault();

                        _objorder.Order_Status = model.Order_Status;
                      
                        db.Entry(_objorder).State = EntityState.Modified;
                        db.SaveChanges();

                    }
                    return new ResultModel { Message = "Success", Status = 1, Response = 1 };
                }
                else
                {
                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = 0 };
                }

            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        [HttpPost]
        public async Task<ResultModel> GetStaffViseOrderHistory(Order model)
        {
            try
            {
                var result = db.Orders.Where(a => a.Staff_Id == model.Staff_Id).ToList();

                if (result != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = result };
                }
                else
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = 1 };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        [HttpPost]
        public async Task<ResultModel> DeliveredOrder(Order model)
        {
            try
            {
                var result = db.Orders.Where(a => a.Id == model.Id).FirstOrDefault();

                result.Received_Amount = model.Received_Amount;
                result.Balance_Amount = model.Balance_Amount;
                result.Customer_Sign = model.Customer_Sign;
                result.Remainder_date = model.Remainder_date;

                db.Entry(result).State = EntityState.Modified;
                db.SaveChanges();

                if (result != null)
                {
                    var OrderDetail = db.OrderHistories.Where(a => a.OrderId == model.Id).ToList();
                    foreach (var item in OrderDetail)
                    {
                        var _objorder = db.OrderHistories.Where(a => a.OrderId == item.OrderId).ToList().FirstOrDefault();

                        _objorder.Order_Status = model.Order_Status;

                        db.Entry(_objorder).State = EntityState.Modified;
                        db.SaveChanges();

                    }

                    Collection collection = new Collection();
                    var details = db.Orders.Where(a => a.Id == model.Id).ToList();
                    foreach (var item in details)
                    {
                        collection.Order_Id = item.Id;
                        collection.Staff_Id = item.Staff_Id;
                        collection.CustomerName = item.CustomerName;
                        collection.EmployeeName = item.Staff_Name;
                        collection.DeliveryDate = item.Delivery_Date;
                        collection.BalanceAmount = item.Balance_Amount;
                        collection.ReceveAmount = item.Received_Amount;
                        collection.TotalAmount = item.TotalAmount;

                        db.Collections.Add(collection);
                        db.SaveChanges();

                    }
                   
                    return new ResultModel { Message = "Success", Status = 1, Response = 1 };
                }
                else
                {
                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = 0 };
                }

            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

    }
}