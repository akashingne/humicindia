﻿using Ecommerce.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace Ecommerce.Controllers
{
    public class CollectionController : ApiController
    {
        ECommeraceEntity db = new ECommeraceEntity();

        [HttpPost]
        public async Task<ResultModel> GetStaffIdViseCollection (Collection model)
        {
            try
            {
                var result = db.Collections.Where(a=> a.Staff_Id == model.Staff_Id).ToList();

                if (result != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = result };
                }
                else
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = 1 };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }
    }
}
