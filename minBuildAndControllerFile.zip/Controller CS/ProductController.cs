﻿using Ecommerce.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace Ecommerce.Controllers
{
    public class ProductController : ApiController
    {
        ECommeraceEntity db = new ECommeraceEntity();

        [HttpPost]
        public ResultModel AddProduct()
        {
            var exMessage = string.Empty;
            try
            {
                string uploadPath = "~/UploadedFiles";
                HttpPostedFile file = null;
                if (HttpContext.Current.Request.Files.Count > 0)
                {
                    file = HttpContext.Current.Request.Files.Get("ProductImage");
                }
                if (null == file)
                {
                    return new ResultModel { Message = "Image file not found", Status = 0, Response = null };

                }
                if (!(file.ContentLength > 0))
                {
                    return new ResultModel { Message = "Image file not found", Status = 0, Response = null };
                }
                string ProductName = HttpContext.Current.Request.Params.Get("ProductName");
                string CategoryName = HttpContext.Current.Request.Params.Get("CategoryName");
                string SubCategoryName = HttpContext.Current.Request.Params.Get("SubCategoryName");
                string Amount = HttpContext.Current.Request.Params.Get("Amount");
                string OfferAmount = HttpContext.Current.Request.Params.Get("OfferAmount");
                string Quantity = HttpContext.Current.Request.Params.Get("Quantity");
                string Stock = HttpContext.Current.Request.Params.Get("Stock");
                string Product_Type = HttpContext.Current.Request.Params.Get("Product_Type");

                if (!Directory.Exists(HttpContext.Current.Server.MapPath(uploadPath)))
                {
                    Directory.CreateDirectory(HttpContext.Current.Server.MapPath(uploadPath));
                }
                file.SaveAs(HttpContext.Current.Server.MapPath($"{uploadPath}/{file.FileName}"));


                Product _ObjProd = new Product();
                _ObjProd.ProductName = ProductName;
                _ObjProd.ProductImage = file.FileName;
                _ObjProd.CategoryName = CategoryName;
                _ObjProd.SubCategoryName = SubCategoryName;
                _ObjProd.Amount = Amount;
                _ObjProd.OfferAmount = OfferAmount;
                _ObjProd.Quantity = Quantity;
                _ObjProd.Stock = Stock;

                var result = db.Products.Where(a => a.ProductName == ProductName).ToList();

                if (result.Count == 0)
                {

                    var CatDetail = db.Categories.Where(a => a.CategoryName == CategoryName).ToList();

                    foreach (var item in CatDetail)
                    {
                        _ObjProd.Product_Type = item.Category_Type;

                        db.Products.Add(_ObjProd);
                        db.SaveChanges();
                    }

                        
                    return new ResultModel { Message = "Data saved", Status = 1, Response = _ObjProd };
                }
                else
                {
                    return new ResultModel { Message = "Product already exist", Status = 0, Response = null };
                }




            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.Message, Status = 0, Response = null };
            }
        }

        //[HttpPost]
        //public async Task<ResultModel> AddProduct(Product model)
        //{
        //    try
        //    {
        //        Product _ObjProd = new Product();

        //        _ObjProd.ProductName = model.ProductName;
        //        _ObjProd.CategoryName = model.CategoryName;
        //        _ObjProd.SubCategoryName = model.SubCategoryName;
        //        _ObjProd.Amount = model.Amount;
        //        _ObjProd.OfferAmount = model.OfferAmount;
        //        _ObjProd.ProductImage = model.ProductImage;
        //        _ObjProd.Quantity = model.Quantity;
        //        _ObjProd.Product_Type = model.Product_Type;

        //        var count = db.Products.Where(a => a.ProductName == model.ProductName).ToList();

        //        if(count.Count == 0)
        //        {
        //            db.Products.Add(_ObjProd);
        //            db.SaveChanges();

        //            if (_ObjProd != null)
        //            {
        //                return new ResultModel { Message = "Success", Status = 1, Response = _ObjProd };
        //            }
        //            else
        //            {
        //                return new ResultModel { Message = "Data Not Found", Status = 0, Response = null };
        //            }
        //        }
        //        else
        //        {
        //            return new ResultModel { Message = "Data Not Found", Status = 0, Response = null };
        //        }
        //    }
        //    catch(Exception ex)
        //    {
        //        return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
        //    }
        //}

        [HttpGet]
        public async Task<ResultModel> GetAllProductList(Product model)
        {
            try
            {
                var result = db.Products.ToList();
                if (result != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = result };
                }
                else
                {
                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = null };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        [HttpPost]
        public async Task<ResultModel> GetProductByType(Product model)
        {
            ResultModel resultModel = new ResultModel();
            try
            {
                var registrations = db.Products.Where(a => a.Product_Type == model.Product_Type).ToList();

                if (registrations != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = registrations };
                }
                else
                {
                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = null };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }

        }

        [HttpPost]
        public async Task<ResultModel> GetProductBySubCategory(Product model)
        {
            ResultModel resultModel = new ResultModel();
            try
            {
                var registrations = db.Products.Where(a => a.SubCategoryName == model.SubCategoryName).ToList();

                if (registrations != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = registrations };
                }
                else
                {
                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = null };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }

        }

        [HttpPost]
        public async Task<ResultModel> GetProductByCategory(Product model)
        {
            ResultModel resultModel = new ResultModel();
            try
            {
                var registrations = db.Products.Where(a => a.CategoryName == model.CategoryName).ToList();

                if (registrations != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = registrations };
                }
                else
                {
                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = null };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }

        }

        [HttpPost]
        public async Task<ResultModel> GetProductById(Product model)
        {
            ResultModel resultModel = new ResultModel();
            try
            {
                var registrations = db.Products.Where(a => a.Id == model.Id).FirstOrDefault();

                if (registrations != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = registrations };
                }
                else
                {
                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = null };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }

        }

        [HttpPost]
        public ResultModel UpdateProducts()
        {
            var exMessage = string.Empty;
            try
            {
                string uploadPath = "~/UploadedFiles";
                HttpPostedFile file = null;

                string ProductId = HttpContext.Current.Request.Params.Get("Id");
                int PId = Int32.Parse(ProductId);

                var _ObjProd = db.Products.Where(a => a.Id == PId).FirstOrDefault();

                if (HttpContext.Current.Request.Files.Count > 0)
                {
                    if (!Directory.Exists(HttpContext.Current.Server.MapPath(uploadPath)))
                    {
                        Directory.CreateDirectory(HttpContext.Current.Server.MapPath(uploadPath));
                    }
                    file = HttpContext.Current.Request.Files.Get("ProductImage");
                    if (null != file)
                    {
                        file.SaveAs(HttpContext.Current.Server.MapPath($"{uploadPath}/{file.FileName}"));
                        _ObjProd.ProductImage = file.FileName;
                    }
                }
                
                
                string ProductName = HttpContext.Current.Request.Params.Get("ProductName");
                string CategoryName = HttpContext.Current.Request.Params.Get("CategoryName");
                string SubCategoryName = HttpContext.Current.Request.Params.Get("SubCategoryName");
                string Amount = HttpContext.Current.Request.Params.Get("Amount");
                string OfferAmount = HttpContext.Current.Request.Params.Get("OfferAmount");
                string Quantity = HttpContext.Current.Request.Params.Get("Quantity");
                string Stock = HttpContext.Current.Request.Params.Get("Stock");
                string Product_Type = HttpContext.Current.Request.Params.Get("Product_Type");

                
                

                


                _ObjProd.ProductName = ProductName;
                
                _ObjProd.CategoryName = CategoryName;
                _ObjProd.SubCategoryName = SubCategoryName;
                _ObjProd.Amount = Amount;
                _ObjProd.OfferAmount = OfferAmount;
                _ObjProd.Quantity = Quantity;
                _ObjProd.Stock = Stock;

                var CatDetail = db.Categories.Where(a => a.CategoryName == CategoryName).ToList();

                foreach (var item in CatDetail)
                {
                    _ObjProd.Product_Type = item.Category_Type;

                    db.Entry(_ObjProd).State = EntityState.Modified;
                    db.SaveChanges();
                }


                return new ResultModel { Message = "Data saved", Status = 1, Response = _ObjProd };




            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.Message, Status = 0, Response = null };
            }
        }

        //[HttpPost]
        //public async Task<ResultModel> UpdateProducts(Product model)
        //{
        //    try
        //    {
        //        var _objreg = db.Products.Where(a => a.Id == model.Id).FirstOrDefault();


        //        if (model.ProductName != null)
        //        {
        //            _objreg.ProductName = model.ProductName;
        //        }
        //        if (model.Amount != null)
        //        {
        //            _objreg.Amount = model.Amount;
        //        }
        //        if (model.OfferAmount != null)
        //        {
        //            _objreg.OfferAmount = model.OfferAmount;
        //        }
        //        if (model.ProductImage != null)
        //        {
        //            _objreg.ProductImage = model.ProductImage;
        //        }
        //        if (model.CategoryName != null)
        //        {
        //            _objreg.CategoryName = model.CategoryName;
        //        }
        //        if (model.SubCategoryName != null)
        //        {
        //            _objreg.SubCategoryName = model.SubCategoryName;
        //        }
        //        if (model.Quantity != null)
        //        {
        //            _objreg.Quantity = model.Quantity;
        //        }

        //        db.Entry(_objreg).State = EntityState.Modified;

        //        db.SaveChanges();

        //        if (_objreg != null)
        //        {
        //            return new ResultModel { Message = "Success", Status = 1, Response = _objreg };
        //        }
        //        else
        //        {
        //            return new ResultModel { Message = "Data Not Found", Status = 0, Response = null };
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
        //    }
        //}

    }
}
