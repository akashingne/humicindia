﻿using Ecommerce.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mail;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.UI;

namespace Ecommerce.Controllers
{
    public class StaffController : ApiController
    {
        ECommeraceEntity db = new ECommeraceEntity();

        [HttpPost]
        public ResultModel AddStaff()
        {
            var exMessage = string.Empty;
            try
            {
                string uploadPath = "~/UploadedFiles";
                HttpPostedFile AddressProof = null;
                HttpPostedFile IdProof = null;
                HttpPostedFile ProfilePic = null;
                if (HttpContext.Current.Request.Files.Count > 0)
                {
                    AddressProof = HttpContext.Current.Request.Files.Get("AddressProof");
                    IdProof = HttpContext.Current.Request.Files.Get("IdProof");
                    ProfilePic = HttpContext.Current.Request.Files.Get("ProfilePic");
                }
                if (null == AddressProof || null == IdProof || null == ProfilePic)
                {
                    return new ResultModel { Message = "Image file not found", Status = 0, Response = null };

                }
                if (!(AddressProof.ContentLength > 0 || IdProof.ContentLength > 0 || ProfilePic.ContentLength > 0))
                {
                    return new ResultModel { Message = "Image file not found", Status = 0, Response = null };
                }
                string EmployeeName = HttpContext.Current.Request.Params.Get("EmployeeName");
                string EmailId = HttpContext.Current.Request.Params.Get("EmailId");
                string MobileNo = HttpContext.Current.Request.Params.Get("MobileNo");
                string Designation = HttpContext.Current.Request.Params.Get("Designation");
                string JoiningDate = HttpContext.Current.Request.Params.Get("JoiningDate");
                string LoginTime = HttpContext.Current.Request.Params.Get("LoginTime");
                string LogoutTime = HttpContext.Current.Request.Params.Get("LogoutTime");
                string WeekendOff = HttpContext.Current.Request.Params.Get("WeekendOff");

                if (!Directory.Exists(HttpContext.Current.Server.MapPath(uploadPath)))
                {
                    Directory.CreateDirectory(HttpContext.Current.Server.MapPath(uploadPath));
                }
                AddressProof.SaveAs(HttpContext.Current.Server.MapPath($"{uploadPath}/{AddressProof.FileName}"));
                IdProof.SaveAs(HttpContext.Current.Server.MapPath($"{uploadPath}/{IdProof.FileName}"));
                ProfilePic.SaveAs(HttpContext.Current.Server.MapPath($"{uploadPath}/{ProfilePic.FileName}"));



                Staff _objStaff = new Staff();

                StringBuilder builder = new StringBuilder();
                builder.Append(RandomString(4, true));
                builder.Append(RandomNumber(1000, 9999));
                builder.Append(RandomString(2, false));
                string password = builder.ToString();

                

                _objStaff.EmployeeName = EmployeeName;
                _objStaff.EmailId = EmailId;
                _objStaff.MobileNo = MobileNo;
                _objStaff.Designation = Designation;
                _objStaff.JoiningDate = JoiningDate;
                _objStaff.ProfilePic = ProfilePic.FileName;
                _objStaff.IdProof = IdProof.FileName;
                _objStaff.AddressProof = AddressProof.FileName;
                _objStaff.Password = password;
                _objStaff.WeekendOff = WeekendOff;
                _objStaff.LoginTime = LoginTime;
                _objStaff.LogoutTime = LogoutTime;

                Random generator = new Random();
                String r = generator.Next(0, 999999).ToString("D6");
                String ref_code = EmployeeName.Substring(0, 5).ToUpper() + r;

                _objStaff.StaffCode = ref_code;

                db.Staffs.Add(_objStaff);
                db.SaveChanges();

                if (_objStaff != null)
                {
                    sendEmailViaWebApi(EmailId, MobileNo, password);
                    return new ResultModel { Message = "Success", Status = 1, Response = _objStaff };
                }
                else
                {
                    return new ResultModel { Message = "No data found", Status = 0, Response = null };
                }




            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.Message, Status = 0, Response = null };
            }
        }

        //[HttpPost]
        //public async Task<ResultModel> AddStaff(Staff Model)
        //{
        //    try
        //    {
        //        Staff _objStaff = new Staff();

        //        StringBuilder builder = new StringBuilder();
        //        builder.Append(RandomString(4, true));
        //        builder.Append(RandomNumber(1000, 9999));
        //        builder.Append(RandomString(2, false));
        //        string password = builder.ToString();

        //        _objStaff.EmployeeName = Model.EmployeeName;
        //        _objStaff.EmailId = Model.EmailId;
        //        _objStaff.MobileNo = Model.MobileNo;
        //        _objStaff.Designation = Model.Designation;
        //        _objStaff.JoiningDate = Model.JoiningDate;
        //        _objStaff.RelevingDate = Model.RelevingDate;
        //        _objStaff.ProfilePic = Model.ProfilePic;
        //        _objStaff.IdProof = Model.IdProof;
        //        _objStaff.AddressProof = Model.AddressProof;
        //        _objStaff.Password = password;
        //        _objStaff.WeekendOff = Model.WeekendOff;
        //        _objStaff.LoginTime = Model.LoginTime;
        //        _objStaff.LogoutTime = Model.LogoutTime;

        //        Random generator = new Random();
        //        String r = generator.Next(0, 999999).ToString("D6");
        //        String ref_code = Model.EmployeeName.Substring(0, 5).ToUpper() + r;

        //        _objStaff.StaffCode = ref_code;

        //        db.Staffs.Add(_objStaff);
        //        db.SaveChanges();

        //        if (_objStaff != null)
        //        {
        //            sendEmailViaWebApi(Model.EmailId, Model.MobileNo, password);
        //            return new ResultModel { Message = "Success", Status = 1, Response = _objStaff };
        //        }
        //        else
        //        {
        //            return new ResultModel { Message = "No data found", Status = 0, Response = null };
        //        }


        //    }
        //    catch (Exception ex)
        //    {
        //        return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
        //    }
        //}

        private void sendEmailViaWebApi(string emailId, string mobileNo, string password)
        {
            MailMessage mail = new MailMessage();
            mail.To.Add(emailId);
            mail.From = new MailAddress("dhanashrihemane78@gmail.com");
            mail.Subject = "HumicIndia staff login details";
            mail.Body = "MobileNo :" + mobileNo + "\n" + "Password :" + password; ;
            mail.IsBodyHtml = true;

            SmtpClient SmtpServer = new SmtpClient();
            SmtpServer.UseDefaultCredentials = false;
            SmtpServer.Credentials = new System.Net.NetworkCredential("dhanashrihemane78@gmail.com", "dhemane02");            
            SmtpServer.Port = 587;
            SmtpServer.Host = "smtp.gmail.com";
            SmtpServer.DeliveryMethod = SmtpDeliveryMethod.Network;                 
            SmtpServer.EnableSsl = true;
            //SmtpServer.Timeout = 1000;

            try
            {
                
                SmtpServer.Send(mail);

            }
            catch (Exception ex)
            {
                
            }
            
        }

        public string RandomString(int size, bool lowerCase)
        {
            StringBuilder builder = new StringBuilder();
            Random random = new Random();
            char ch;
            for (int i = 0; i < size; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
                builder.Append(ch);
            }
            if (lowerCase)
                return builder.ToString().ToLower();
            return builder.ToString();
        }

        public int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }

        [HttpGet]
        public async Task<ResultModel> GetStaff()
        {
            try
            {
                var result = db.Staffs.ToList();

                if(result != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = result };
                }
                else
                {
                    return new ResultModel { Message = "No data found", Status = 0, Response = null };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        [HttpPost]
        public async Task<ResultModel> GetIdViseStaff(Staff model)
        {
            try
            {
                var result = db.Staffs.Where(a => a.Id == model.Id).ToList();

                if (result != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = result };
                }
                else
                {
                    return new ResultModel { Message = "No data found", Status = 0, Response = null };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        [HttpPost]
        public async Task<ResultModel> UpdateLogintime (Staff model)
        {
            try
            {
                var result = db.Staffs.Where(a => a.StaffCode == model.StaffCode).FirstOrDefault();

                result.LoginTime = model.LoginTime;
                result.LogoutTime = model.LogoutTime;

                db.Entry(result).State = EntityState.Modified;
                db.SaveChanges();

                if (result != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = result };
                }
                else
                {
                    return new ResultModel { Message = "No data found", Status = 0, Response = null };
                }

            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        [HttpPost]
        public async Task<ResultModel> StaffLogin(Staff model)
        {
            try
            {

                var result = db.Staffs.Where(a => a.MobileNo == model.MobileNo && a.Password == model.Password).FirstOrDefault();

                result.LoginStatus = model.LoginStatus;

                db.Entry(result).State = EntityState.Modified;
                db.SaveChanges();

                var staff_detail = db.Staffs.Where(a => a.MobileNo == model.MobileNo).ToList();                    

                if (result != null)
                {
                    Attendance _objAttendance = new Attendance();

                    foreach (var item in staff_detail)
                    {
                        _objAttendance.Staff_Id = item.Id;
                        _objAttendance.EmployeeName = item.EmployeeName;
                        _objAttendance.UserName = item.MobileNo;
                        _objAttendance.LoginTime = DateTime.Now.ToString("hh:mm:ss"); ;
                        _objAttendance.Date = System.DateTime.Now.Date.ToString("dd/MM/yyyy");
                    }

                    var attemdance_detail = db.Attendances.Where(a => a.Date == _objAttendance.Date).ToList();

                    if (attemdance_detail.Count == 0)
                    {
                        db.Attendances.Add(_objAttendance);
                        db.SaveChanges();
                    }

                    return new ResultModel { Message = "Success", Status = 1, Response = result };

                }
                else
                {
                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = null };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        [HttpPost]
        public async Task<ResultModel> LoginStaff(Staff model)
        {
            try
            {
                var result = db.Staffs.Where(a => a.MobileNo == model.MobileNo && a.Password == model.Password).FirstOrDefault();

                result.LoginStatus = model.LoginStatus;

                db.Entry(result).State = EntityState.Modified;
                db.SaveChanges();

                if (result != null)
                {

                    return new ResultModel { Message = "Success", Status = 1, Response = 1 };

                }
                else
                {
                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = null };
                }

            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        [HttpPost]
        public async Task<ResultModel> GetIdViseData(Order model)
        {
            try
            {
                var result = db.Orders.Where(a => a.Staff_Id == model.Staff_Id).ToList();
                if (result != null)
                {

                    return new ResultModel { Message = "Success", Status = 1, Response = 1 };

                }
                else
                {
                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = null };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        [HttpPost]
        public async Task<ResultModel> GetMobileNoViseData(Staff model)
        {
            try
            {
                var result = db.Staffs.Where(a => a.MobileNo == model.MobileNo).ToList();
                if (result != null)
                {

                    return new ResultModel { Message = "Success", Status = 1, Response = result };

                }
                else
                {
                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = 0 };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        [HttpPost]
        public async Task<ResultModel> ForgetPassword(Staff model)
        {
            try
            {


                var result = db.Staffs.Where(a => a.MobileNo == model.MobileNo).FirstOrDefault();

                if (model.Password != null)
                {
                    result.Password = model.Password;
                }

                db.Entry(result).State = EntityState.Modified;
                db.SaveChanges();


                if (result != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = result };
                }
                else
                {
                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = null };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        [HttpPost]
        public ResultModel EditStaff()
        {
            var exMessage = string.Empty;
            try
            {
                string uploadPath = "~/UploadedFiles";
                HttpPostedFile AddressProof = null;
                HttpPostedFile IdProof = null;
                HttpPostedFile ProfilePic = null;

                string Id = HttpContext.Current.Request.Params.Get("Id");

                int SID = Int32.Parse(Id);

                var _objStaff = db.Staffs.Where(a => a.Id == SID).FirstOrDefault();

                if (HttpContext.Current.Request.Files.Count > 0)
                {
                    if (!Directory.Exists(HttpContext.Current.Server.MapPath(uploadPath)))
                    {
                        Directory.CreateDirectory(HttpContext.Current.Server.MapPath(uploadPath));
                    }

                    AddressProof = HttpContext.Current.Request.Files.Get("AddressProof");
                    if (null != AddressProof)
                    {
                        AddressProof.SaveAs(HttpContext.Current.Server.MapPath($"{uploadPath}/{AddressProof.FileName}"));
                        _objStaff.AddressProof = AddressProof.FileName;
                    }

                    IdProof = HttpContext.Current.Request.Files.Get("IdProof");
                    if (null != IdProof)
                    {
                        IdProof.SaveAs(HttpContext.Current.Server.MapPath($"{uploadPath}/{IdProof.FileName}"));
                        _objStaff.IdProof = IdProof.FileName;
                    }

                    ProfilePic = HttpContext.Current.Request.Files.Get("ProfilePic");
                    if (null != ProfilePic)
                    {
                        ProfilePic.SaveAs(HttpContext.Current.Server.MapPath($"{uploadPath}/{ProfilePic.FileName}"));
                        _objStaff.ProfilePic = ProfilePic.FileName;
                    }
                }

                
                string EmployeeName = HttpContext.Current.Request.Params.Get("EmployeeName");
                string EmailId = HttpContext.Current.Request.Params.Get("EmailId");
                string Designation = HttpContext.Current.Request.Params.Get("Designation");
                string JoiningDate = HttpContext.Current.Request.Params.Get("JoiningDate");
                string RelevingDate = HttpContext.Current.Request.Params.Get("RelevingDate");
                string LoginTime = HttpContext.Current.Request.Params.Get("LoginTime");
                string LogoutTime = HttpContext.Current.Request.Params.Get("LogoutTime");
                string WeekendOff = HttpContext.Current.Request.Params.Get("WeekendOff");

                _objStaff.EmployeeName = EmployeeName;
                _objStaff.EmailId = EmailId;
                _objStaff.Designation = Designation;
                _objStaff.JoiningDate = JoiningDate;
                _objStaff.RelevingDate = RelevingDate;
                _objStaff.WeekendOff = WeekendOff;
                _objStaff.LoginTime = LoginTime;
                _objStaff.LogoutTime = LogoutTime;

                if (_objStaff != null)
                {
                    db.Entry(_objStaff).State = EntityState.Modified;
                    db.SaveChanges();

                    return new ResultModel { Message = "Success", Status = 1, Response = _objStaff };
                }
                else
                {
                    return new ResultModel { Message = "No data found", Status = 0, Response = null };
                }




            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.Message, Status = 0, Response = null };
            }
        }

        //[HttpPost]
        //public async Task<ResultModel> EditStaff(Staff Model)
        //{
        //    try
        //    {
        //        var _objStaff = db.Staffs.Where(a => a.Id == Model.Id).FirstOrDefault();


        //        _objStaff.EmployeeName = Model.EmployeeName;
        //        _objStaff.EmailId = Model.EmailId;
        //        _objStaff.Designation = Model.Designation;
        //        _objStaff.JoiningDate = Model.JoiningDate;
        //        _objStaff.RelevingDate = Model.RelevingDate;
        //        _objStaff.ProfilePic = Model.ProfilePic;
        //        _objStaff.IdProof = Model.IdProof;
        //        _objStaff.AddressProof = Model.AddressProof;
        //        _objStaff.WeekendOff = Model.WeekendOff;
        //        _objStaff.LoginTime = Model.LoginTime;
        //        _objStaff.LogoutTime = Model.LogoutTime;
                

        //        if (_objStaff != null)
        //        {
        //            db.Entry(_objStaff).State = EntityState.Modified;
        //            db.SaveChanges();

        //            return new ResultModel { Message = "Success", Status = 1, Response = _objStaff };
        //        }
        //        else
        //        {
        //            return new ResultModel { Message = "No data found", Status = 0, Response = null };
        //        }


        //    }
        //    catch (Exception ex)
        //    {
        //        return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
        //    }
        //}


    }
}
