﻿using Ecommerce.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace Ecommerce.Controllers
{
    public class OfferController : ApiController
    {
        ECommeraceEntity db = new ECommeraceEntity();

        [HttpPost]
        public ResultModel AddOffer()
        {
            try
            {
                string uploadPath = "~/UploadedFiles";
                HttpPostedFile file = null;
                if (HttpContext.Current.Request.Files.Count > 0)
                {
                    file = HttpContext.Current.Request.Files.Get("OfferImage");
                }
                if (null == file)
                {
                    return new ResultModel { Message = "Image file not found", Status = 0, Response = null };

                }
                if (!(file.ContentLength > 0))
                {
                    return new ResultModel { Message = "Image file not found", Status = 0, Response = null };
                }
                string Title = HttpContext.Current.Request.Params.Get("Title");
                string Details = HttpContext.Current.Request.Params.Get("Details");
                string Discount = HttpContext.Current.Request.Params.Get("Discount");
                if (!Directory.Exists(HttpContext.Current.Server.MapPath(uploadPath)))
                {
                    Directory.CreateDirectory(HttpContext.Current.Server.MapPath(uploadPath));
                }
                file.SaveAs(HttpContext.Current.Server.MapPath($"{uploadPath}/{file.FileName}"));
                Offer _ObjOffer = new Offer();

                _ObjOffer.Title = Title;
                _ObjOffer.Details = Details;
                _ObjOffer.Discount = Discount;
                _ObjOffer.OfferImage = file.FileName;

                db.Offers.Add(_ObjOffer);
                db.SaveChanges();

                if (_ObjOffer != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = _ObjOffer };
                }
                else
                {
                    return new ResultModel { Message = "No data found", Status = 0, Response = null };
                }
            }
            catch (Exception ex)
            {

                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        //[HttpPost]
        //public async Task<ResultModel> AddOffer1(Offer model)
        //{
        //    try
        //    {
        //        Offer _ObjOffer = new Offer();

        //        _ObjOffer.Title = model.Title;
        //        _ObjOffer.Details = model.Details;
        //        _ObjOffer.Discount = model.Discount;
        //        _ObjOffer.OfferImage = model.OfferImage;

        //        db.Offers.Add(_ObjOffer);
        //        db.SaveChanges();

        //        if (_ObjOffer != null)
        //        {
        //            return new ResultModel { Message = "Success", Status = 1, Response = _ObjOffer };
        //        }
        //        else
        //        {
        //            return new ResultModel { Message = "No data found", Status = 0, Response = null };
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
        //    }
        //}

        [HttpGet]
        public async Task<ResultModel> GetAllOffer()
        {
            try
            {
                var result = db.Offers.ToList();

                if (result != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = result };
                }
                else
                {
                    return new ResultModel { Message = "No data found", Status = 0, Response = null };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        [HttpPost]
        public async Task<ResultModel> GetIdViseOffer(Offer model)
        {
            try
            {
                var result = db.Offers.Where(a=> a.Id == model.Id).ToList();

                if (result != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = result };
                }
                else
                {
                    return new ResultModel { Message = "No data found", Status = 0, Response = null };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        [HttpPost]
        public ResultModel EditOffer()
        {
            var exMessage = string.Empty;
            try
            {
                string uploadPath = "~/UploadedFiles";
                HttpPostedFile file = null;

                string OfferId = HttpContext.Current.Request.Params.Get("Id");
                int OId = Int32.Parse(OfferId);

                var _ObjOffer = db.Offers.Where(a => a.Id == OId).FirstOrDefault();

                if (HttpContext.Current.Request.Files.Count > 0)
                {
                    if (!Directory.Exists(HttpContext.Current.Server.MapPath(uploadPath)))
                    {
                        Directory.CreateDirectory(HttpContext.Current.Server.MapPath(uploadPath));
                    }

                    file = HttpContext.Current.Request.Files.Get("OfferImage");
                    if (null != file)
                    {
                        file.SaveAs(HttpContext.Current.Server.MapPath($"{uploadPath}/{file.FileName}"));
                        _ObjOffer.OfferImage = file.FileName;
                    }
                }


                string Title = HttpContext.Current.Request.Params.Get("Title");
                string Details = HttpContext.Current.Request.Params.Get("Details");
                string Discount = HttpContext.Current.Request.Params.Get("Discount");


                _ObjOffer.Title = Title;
                _ObjOffer.Details = Details;
                _ObjOffer.Discount = Discount;

                db.Entry(_ObjOffer).State = EntityState.Modified;
                db.SaveChanges();

                return new ResultModel { Message = "Data saved", Status = 1, Response = _ObjOffer };



            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.Message, Status = 0, Response = null };
            }
        }

    }
}
