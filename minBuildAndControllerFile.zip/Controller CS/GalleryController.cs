﻿using Ecommerce.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace Ecommerce.Controllers
{
    public class GalleryController : ApiController
    {
        ECommeraceEntity db = new ECommeraceEntity();

        [HttpPost]
        public ResultModel AddImage()
        {
            try
            {
                string uploadPath = "~/UploadedFiles";
                HttpPostedFile file = null;
                if (HttpContext.Current.Request.Files.Count > 0)
                {
                    file = HttpContext.Current.Request.Files.Get("Photo");
                }
                if (null == file)
                {
                    return new ResultModel { Message = "Image file not found", Status = 0, Response = null };

                }
                if (!(file.ContentLength > 0))
                {
                    return new ResultModel { Message = "Image file not found", Status = 0, Response = null };
                }
                string ExpiryDate = HttpContext.Current.Request.Params.Get("ExpiryDate");
                if (!Directory.Exists(HttpContext.Current.Server.MapPath(uploadPath)))
                {
                    Directory.CreateDirectory(HttpContext.Current.Server.MapPath(uploadPath));
                }
                file.SaveAs(HttpContext.Current.Server.MapPath($"{uploadPath}/{file.FileName}"));

                Gallery _ObjGallery = new Gallery();
                _ObjGallery.Photo = file.FileName;
                _ObjGallery.ActiveStatus = 1;
                _ObjGallery.ExpiryDate = ExpiryDate;

                db.Galleries.Add(_ObjGallery);
                db.SaveChanges();

                if (_ObjGallery != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = _ObjGallery };
                }
                else
                {
                    return new ResultModel { Message = "No data found", Status = 0, Response = null };
                }
            }
            catch (Exception ex)
            {

                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        //[HttpPost]
        //public async Task<ResultModel> AddImage1(Gallery model)
        //{
        //    try
        //    {
        //        Gallery _ObjGallery = new Gallery();

        //        _ObjGallery.Photo = model.Photo;
        //        _ObjGallery.ActiveStatus = 1;
        //        _ObjGallery.ExpiryDate = model.ExpiryDate;

        //        db.Galleries.Add(_ObjGallery);
        //        db.SaveChanges();


        //        if (_ObjGallery != null)
        //        {
        //            return new ResultModel { Message = "Success", Status = 1, Response = _ObjGallery };
        //        }
        //        else
        //        {
        //            return new ResultModel { Message = "No data found", Status = 0, Response = null };
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
        //    }
        //}

        [HttpGet]
        public async Task<ResultModel> GetAllPhotos()
        {
            try
            {
                var result = db.Galleries.ToList();

                if(result != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = result };
                }
                else
                {
                    return new ResultModel { Message = "No data found", Status = 0, Response = null };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        
    }
}
