﻿using Ecommerce.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace Ecommerce.Controllers
{
    public class SubCategoryController : ApiController
    {
        ECommeraceEntity db = new ECommeraceEntity();

        [HttpPost]
        public ResultModel AddSubCategory()
        {
            var exMessage = string.Empty;
            try
            {
                string uploadPath = "~/UploadedFiles";
                HttpPostedFile file = null;
                if (HttpContext.Current.Request.Files.Count > 0)
                {
                    file = HttpContext.Current.Request.Files.Get("SubCategoryImage");
                }
                if (null == file)
                {
                    return new ResultModel { Message = "Image file not found", Status = 0, Response = null };

                }
                if (!(file.ContentLength > 0))
                {
                    return new ResultModel { Message = "Image file not found", Status = 0, Response = null };
                }
                string SubCategoryName = HttpContext.Current.Request.Params.Get("SubCategoryName");
                string CategoryNane = HttpContext.Current.Request.Params.Get("CategoryNane");

                if (!Directory.Exists(HttpContext.Current.Server.MapPath(uploadPath)))
                {
                    Directory.CreateDirectory(HttpContext.Current.Server.MapPath(uploadPath));
                }
                file.SaveAs(HttpContext.Current.Server.MapPath($"{uploadPath}/{file.FileName}"));

               

                SubCategory _ObjSub = new SubCategory();
                _ObjSub.CategoryNane = CategoryNane;
                _ObjSub.SubCategoryImage = file.FileName;
                _ObjSub.SubCategoryName = SubCategoryName;

                var result = db.SubCategories.Where(a => a.SubCategoryName == SubCategoryName).ToList();

                if (result.Count == 0)
                {
                    var CatDetail = db.Categories.Where(a => a.CategoryName == CategoryNane).ToList();
                    foreach (var item in CatDetail)
                    {
                        _ObjSub.Category_Type = item.Category_Type;
                        db.SubCategories.Add(_ObjSub);
                        db.SaveChanges();
                    }

                    return new ResultModel { Message = "Data saved", Status = 1, Response = _ObjSub };

                }
                else
                {
                    return new ResultModel { Message = "Sub Category name is already exist", Status = 0, Response = null };
                }


                    
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.Message, Status = 0, Response = null };
            }
        }

        //[HttpPost]
        //public async Task<ResultModel> AddSubCategory (SubCategory model)
        //{
        //    try
        //    {

        //        SubCategory _ObjSub = new SubCategory();

        //        _ObjSub.CategoryNane = model.CategoryNane;
        //        _ObjSub.SubCategoryImage = model.SubCategoryImage;
        //        _ObjSub.SubCategoryName = model.SubCategoryName;
                
        //        var result = db.SubCategories.Where(a => a.SubCategoryName == model.SubCategoryName).ToList();

        //        if (result.Count == 0)
        //        {
        //            var CartDetail = db.Categories.Where(a => a.CategoryName == model.CategoryNane).ToList();
        //            foreach (var item in CartDetail)
        //            {
        //                _ObjSub.Category_Type = item.Category_Type;

        //                db.SubCategories.Add(_ObjSub);
        //                db.SaveChanges();

        //            }

        //            if (_ObjSub != null)
        //            {
        //                return new ResultModel { Message = "Success", Status = 1, Response = _ObjSub };
        //            }
        //            else
        //            {
        //                return new ResultModel { Message = "No data found", Status = 0, Response = null };
        //            }
        //        }
        //        else
        //        {
        //            return new ResultModel { Message = "Category name is already exist", Status = 0, Response = null };
        //        }
          

        //    }
        //    catch (Exception ex)
        //    {
        //        return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
        //    }
        //}

        [HttpGet]
        public async Task<ResultModel> GetAllSubCategories ()
        {
            try
            {
                var result = db.SubCategories.ToList();

                if (result != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = result };
                }
                {
                    return new ResultModel { Message = "No data found", Status = 0, Response = null };
                }

            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }


        [HttpPost]
        public async Task<ResultModel> GetCategoryByType(SubCategory model)
        {
            ResultModel resultModel = new ResultModel();
            try
            {
                var registrations = db.SubCategories.Where(a => a.Category_Type == model.Category_Type).ToList();

                if (registrations != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = registrations };
                }
                else
                {
                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = null };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }

        }

        [HttpPost]
        public async Task<ResultModel> GetCategoryViseData (SubCategory model)
        {
            try
            {
                var result = db.SubCategories.Where(a => a.CategoryNane == model.CategoryNane).ToList();

                if (result != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = result };
                }
                else
                {
                    return new ResultModel { Message = "No data found", Status = 0, Response = null };
                }
                
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        [HttpPost]
        public async Task<ResultModel> GetIdViseData(SubCategory model)
        {
            try
            {
                var result = db.SubCategories.Where(a => a.Id == model.Id).FirstOrDefault();

                if (result != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = result };
                }
                else
                {
                    return new ResultModel { Message = "No data found", Status = 0, Response = null };
                }

            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

        [HttpPost]
        public ResultModel EditSubCategory()
        {
            var exMessage = string.Empty;
            try
            {
                string uploadPath = "~/UploadedFiles";
                HttpPostedFile file = null;

                string CategoryId = HttpContext.Current.Request.Params.Get("Id");
                int CId = Int32.Parse(CategoryId);

                var _ObjSub = db.SubCategories.Where(a => a.Id == CId).FirstOrDefault();

                if (HttpContext.Current.Request.Files.Count > 0)
                {
                    if (!Directory.Exists(HttpContext.Current.Server.MapPath(uploadPath)))
                    {
                        Directory.CreateDirectory(HttpContext.Current.Server.MapPath(uploadPath));
                    }

                    file = HttpContext.Current.Request.Files.Get("SubCategoryImage");
                    if (null != file)
                    {
                        file.SaveAs(HttpContext.Current.Server.MapPath($"{uploadPath}/{file.FileName}"));
                        _ObjSub.SubCategoryImage = file.FileName;
                    }
                }
                
                
                string SubCategoryName = HttpContext.Current.Request.Params.Get("SubCategoryName");
                string CategoryNane = HttpContext.Current.Request.Params.Get("CategoryNane");

                
                

                

                _ObjSub.CategoryNane = CategoryNane;
                
                _ObjSub.SubCategoryName = SubCategoryName;

                var CatDetail = db.Categories.Where(a => a.CategoryName == CategoryNane).ToList();
                foreach (var item in CatDetail)
                {
                    _ObjSub.Category_Type = item.Category_Type;
                    db.Entry(_ObjSub).State = EntityState.Modified;
                    db.SaveChanges();
                }

                return new ResultModel { Message = "Data saved", Status = 1, Response = _ObjSub };



            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.Message, Status = 0, Response = null };
            }
        }

        [HttpPost]
        public async Task<ResultModel> UpdateCategoryrData(SubCategory model)
        {
            try
            {
               

                var result = db.SubCategories.Where(a => a.Id == model.Id).FirstOrDefault();

                if (model.CategoryNane != null)
                {
                    result.CategoryNane = model.CategoryNane;
                }
                if (model.SubCategoryImage != null)
                {
                    result.SubCategoryImage = model.SubCategoryImage;
                }

                db.Entry(result).State = EntityState.Modified;
                db.SaveChanges();


                if (result != null)
                {
                    return new ResultModel { Message = "Success", Status = 1, Response = result };
                }
                else
                {
                    return new ResultModel { Message = "Data Not Found", Status = 0, Response = null };
                }
            }
            catch (Exception ex)
            {
                return new ResultModel { Message = ex.ToString(), Status = 0, Response = null };
            }
        }

    }
}
